import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../auth.service';
import { CommonModule } from '@angular/common';
import { CrearCuentaComponent } from '../crear-cuenta/crear-cuenta.component';
import { CrearCuentaService } from '../crear-cuenta.service';
import { Usuario } from '../Usuario';

@Component({
  selector: 'app-navbar',
  imports: [RouterLink, CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css',
})
export class NavbarComponent implements OnInit {
  esAdmin!: boolean;
  menuAbierto = false;
  user!:string;
  img!:string;

  constructor(private authService: AuthService, private router: Router, private crearCuentaService:CrearCuentaService) {}

  ngOnInit(): void {
    this.validarAdmin();
    this.extraerUser();
    this.extraerUrl();
  }

  public extraerUrl():void{
    this.crearCuentaService.getUsuarioByUsername(this.user).subscribe({
      next: (usuario:Usuario) => {
        this.img = usuario.imagenUrl
      },
      error: (err) => console.log('Error al recuperar usuario ' , err)
    })
  }

  public validarAdmin(): void {
    if (this.authService.getUserInfo()?.get('roles')[0] === 'ROLE_ADMIN')
      this.esAdmin = true;
    else this.esAdmin = false;
  }

  public extraerUser():void{
    this.user = this.authService.getUserInfo()?.get('username');
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/']);
  }


  toggleMenu() {
    this.menuAbierto = !this.menuAbierto;
  }
}
