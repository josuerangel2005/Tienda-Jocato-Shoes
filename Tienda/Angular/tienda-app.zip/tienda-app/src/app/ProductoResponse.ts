import { Producto } from './Producto';

export interface ProductoResponse {
  metadata: {
    'Date: ': string;
    'Mensaje: ': string;
    'Code: ': string;
  }[];
  
  productoResponse: {
    productos: Producto[];
  };
}
