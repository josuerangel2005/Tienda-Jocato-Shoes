import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PngService {

  private apiKey = '4oZxiXiwp9cQUBryG2KZzZNT';
  private apiUrl = 'https://api.remove.bg/v1.0/removebg';

  constructor(private httpClient: HttpClient) {}


  removeBackground(file: File): Observable<Blob> {
    const formData = new FormData();
    formData.append('image_file', file);
    formData.append('size', 'auto');

    const headers = new HttpHeaders({
      'X-Api-Key': this.apiKey
    });

    return this.httpClient.post(this.apiUrl, formData, {
      headers,
      responseType: 'blob'
    });
  }
}
