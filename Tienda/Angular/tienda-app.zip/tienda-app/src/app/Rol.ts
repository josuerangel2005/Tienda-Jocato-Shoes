export class Rol {
  id!: number;
  authority: string; 

  constructor(id:number, authority:string){
    this.id = id;
    this.authority = authority;
  }
}
