import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const token = authService.getToken();

  const excludedUrls = [
    'http://localhost:8080/api/images/upload',
    'https://api.remove.bg/v1.0/removebg',
    'http://localhost:4042/api/email/enviar'
  ];

  if (excludedUrls.some(url => req.url.startsWith(url))) {
    return next(req);
  }

  if (token) {
    const cloned = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${token}`),
    });
    return next(cloned);
  }

  return next(req);
};
