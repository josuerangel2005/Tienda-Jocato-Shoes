import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { JWT } from './JWT';
import { User } from './USER';

@Injectable({
  providedIn: 'root'
})
export class IniciarService {

url:string = 'http://localhost:8082/v2/authenticate';

  constructor(private httpClient:HttpClient) { }

  public iniciarSesion(user:User):Observable<JWT>{
    return this.httpClient.post<JWT>(this.url,user)
  }
}
