import { Injectable } from '@angular/core';
import { Producto } from './Producto';
import { DatosService } from './datos.service';
import { Subject } from 'rxjs';
import { ProductoResponse } from './ProductoResponse';
import { PngService } from './png.service';
import { OrdenRequest } from './OrdenRequest';
import { Orden } from './Orden';
@Injectable({
  providedIn: 'root',
})
export class ProductoService {
  productos!: ProductoResponse;
  imagenSinFondo!:File;

  constructor(private datosService: DatosService, private pgnService:PngService) {}

  //Observable para notificar cambios
  productosActualizados = new Subject<ProductoResponse>();

  public obtenerProductos() {
    return this.datosService.obtenerProductos();
  }

  public guardarProducto(producto: Producto, id: number | null = null) {
    if(id === null){
      return this.datosService.guardarProducto(producto);
    }
    return this.datosService.actualizarProducto(producto,id);
  }
  //Refresco productos
  public refrescarProductos() {
    this.obtenerProductos().subscribe((data: ProductoResponse) => {
      this.setProductos(data);
    });
  }

  public setProductos(productos: ProductoResponse) {
    this.productos = productos;
    this.productosActualizados.next(this.productos); //emite la actualización
  }

  public borrarFondo(file:File){
    return this.pgnService.removeBackground(file);
  }

  public borrarProducto(id:number){
    return this.datosService.eliminarProducto(id);
  }

  public generarPDFCompra(OrdenRequest:OrdenRequest){
    return this.datosService.generarPDFCompra(OrdenRequest);
  }

  public guardarOrden(orden:Orden){
    return this.datosService.guardarOrden(orden);
  }
}
