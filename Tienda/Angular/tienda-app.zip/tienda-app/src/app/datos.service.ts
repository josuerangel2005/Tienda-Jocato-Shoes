import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Producto } from './Producto';
import { Observable } from 'rxjs';
import { ProductoResponse } from './ProductoResponse';
import { OrdenRequest } from './OrdenRequest';
import { Orden } from './Orden';

@Injectable({
  providedIn: 'root',
})
export class DatosService {
  url: string = 'http://localhost:8081/v4/';
  url2: string = 'http://localhost:8081/orden/pdf';
  url3: string = 'http://localhost:8081/api/ordenes';

  constructor(private httpCliente: HttpClient) {}

  public obtenerProductos():Observable<ProductoResponse>{
    return this.httpCliente.get<ProductoResponse>(`${this.url}productos`);
  }

  public guardarProducto(producto:Producto):Observable<ProductoResponse>{
    return this.httpCliente.post<ProductoResponse>(`${this.url}productos`,producto);
  }

  public actualizarProducto(producto:Producto, id:number):Observable<ProductoResponse>{
    return this.httpCliente.put<ProductoResponse>(`${this.url}productos/${id}`,producto)
  }

  public eliminarProducto(id:number):Observable<ProductoResponse>{
    return this.httpCliente.delete<ProductoResponse>(`${this.url}productos/${id}`);
  }

  public generarPDFCompra(OrdenRequest:OrdenRequest):Observable<string>{
    return this.httpCliente.post(this.url2,OrdenRequest, {responseType: 'text'});
  }

  public guardarOrden(orden:Orden):Observable<Orden>{
    return this.httpCliente.post<Orden>(this.url3, orden);
  }


  
}
