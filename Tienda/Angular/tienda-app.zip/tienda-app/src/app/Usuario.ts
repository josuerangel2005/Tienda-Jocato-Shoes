import { Rol } from './Rol';

export class Usuario {
  id?: number;
  username: string;
  password: string;
  documento:string;
  direccion:string;
  nombre:string;
  apellido:string;
  enabled: boolean;
  roles: Rol[];
  imagenUrl:string;
  email:string;

  constructor(
    username: string,
    password: string,
    direccion:string,
    nombre:string,
    apellido:string,
    documento:string,
    enabled: boolean,
    roles: Rol[] = [],
    imagenUrl:string,
    email:string,
    id?: number
  ) {
    this.username = username;
    this.password = password;
    this.direccion = direccion;
    this.nombre = nombre;
    this.apellido = apellido;
    this.documento = documento;
    this.enabled = enabled;
    this.roles = roles;
    this.imagenUrl = imagenUrl;
    this.email = email;
    this.id = id;
  }
}
