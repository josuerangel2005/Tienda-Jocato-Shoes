import { CommonModule } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CrearCuentaService } from '../crear-cuenta.service';
import { Usuario } from '../Usuario';
import { Rol } from '../Rol';
import { ImagenService } from '../imagen.service';

@Component({
  selector: 'app-crear-cuenta',
  imports: [RouterLink, FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './crear-cuenta.component.html',
  styleUrl: './crear-cuenta.component.css',
})
export class CrearCuentaComponent {
  cuentaForm: FormGroup;
  public mostrarCodigo: boolean = false;
  private codigoAdminTrue = 'hola123';
  public imagen!: File;
  errorImagen: boolean = false;
  @ViewChild('imageInput') imageInput!: ElementRef<HTMLInputElement>;

  constructor(
    private formBuilder: FormBuilder,
    private crearCuentaService: CrearCuentaService,
    private router: Router,
    private imagenService: ImagenService
  ) {
    this.cuentaForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', Validators.required],
      direccion:['', Validators.required],
      nombre: ['', Validators.required],
      apellido:['', Validators.required],
      documento:['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      codigoAdmin: [''],
    });
  }

  public onFotoSeleccionada(event: Event): void {
    const target = event.target as HTMLInputElement;

    if (target.files && target.files.length > 0) {
      this.imagen = target.files[0];
    }
  }

  public onAdminChange(event: Event): void {
    const valor = (event.target as HTMLInputElement).value.trim().toLowerCase();

    const control = this.cuentaForm.get('codigoAdmin');

    if (valor === 'si') {
      this.mostrarCodigo = true;
      control?.setValidators([Validators.required]);
    } else {
      this.mostrarCodigo = false;
      control?.clearValidators();
      control?.setValue('');
      control?.markAsUntouched();
      control?.markAsPristine();
    }
      control?.updateValueAndValidity();

  }

  public validarDatos(): void {
    if (this.cuentaForm.invalid) {
      this.cuentaForm.markAllAsTouched();
      return;
    }
    if (!this.imageInput.nativeElement.files?.length) {
      this.errorImagen = true;
      return;
    } else {
      this.errorImagen = false;
    }
    this.crearUsuario(
      this.cuentaForm.value.username,
      this.cuentaForm.value.password,
      this.cuentaForm.value.direccion,
      this.cuentaForm.value.nombre,
      this.cuentaForm.value.apellido,
      this.cuentaForm.value.documento,
      this.cuentaForm.value.email,
      this.cuentaForm.value.codigoAdmin,
      this.imagen
    );
  }

  public crearUsuario(
    username: string,
    password: string,
    direccion:string,
    nombre:string,
    apellido:string,
    documento:string,
    email: string,
    codigoAdmin: string,
    imagen: File
  ): void {
    const formData: FormData = new FormData();
    formData.append('file', imagen);

    this.imagenService.guardarImagen(formData).subscribe({
      next: (url: string) => {
        const urlS: string = url;

        if (this.codigoAdminTrue === codigoAdmin) {
          const user: Usuario = new Usuario(
            username,
            password,
            direccion,
            nombre,
            apellido,
            documento,
            true,
            [new Rol(2, 'ROLE_ADMIN')],
            urlS,
            email
          );
          this.guardarUsuario(user);

          return;
        }
        const user: Usuario = new Usuario(
          username,
          password,
          direccion,
          nombre,
          apellido,
          documento,
          true,
          [new Rol(1, 'ROLE_USER')],
          urlS,
          email
        );
        this.guardarUsuario(user);
      },
      error: (err) =>
        console.error('Error al subir la imagen del usuario ' + err),
    });
  }

  public guardarUsuario(user: Usuario): void {
    this.crearCuentaService.guardarUsuario(user).subscribe({
      next: (data: Usuario) => {
        this.router.navigate(['/']);
      },
      error: (err) => console.error('Error al guardar el usuario:', err.error),
    });
  }
}
