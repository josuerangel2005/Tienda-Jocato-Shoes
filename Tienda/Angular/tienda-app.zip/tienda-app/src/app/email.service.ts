import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EmailRequest } from './EmailRequest';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EmailService {

  url:string = 'http://localhost:4042/api/email/enviar';

  constructor(private httpCliente: HttpClient) {}

  enviarEmail(emailRequest:EmailRequest):Observable<string>{
    return this.httpCliente.post(this.url, emailRequest, {responseType: 'text'});
  }
}
