export class EmailRequest{
    to:string;
    subject:string;
    html:string;

    constructor(to:string,
    subject:string,
    html:string){
        this.to = to;
        this.subject = subject;
        this.html = html;
    }
}