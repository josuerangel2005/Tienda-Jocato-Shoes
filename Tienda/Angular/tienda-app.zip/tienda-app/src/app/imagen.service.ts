import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ImagenService {

  url:string = 'http://localhost:8080/api/images/upload';

  constructor(private htppClient:HttpClient) {}

  public guardarImagen(formData: FormData): Observable<string> {
  return this.htppClient.post(this.url, formData, { responseType: 'text' });
}

}
