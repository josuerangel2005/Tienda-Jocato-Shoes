import { Component } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { FormComponent } from "./form/form.component";
import { ProductosComponent } from "./productos/productos.component";
import { NavbarComponent } from "./navbar/navbar.component";
import { CommonModule } from '@angular/common';
import { filter } from 'rxjs';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormComponent, ProductosComponent, NavbarComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  mostrarNavbar = true;

  constructor(private router:Router){
    this.router.events
    .pipe(filter(event => event instanceof NavigationEnd))
    .subscribe((event:any) => {
      const rutasSinNavbar = ['/', '/crear'];
      this.mostrarNavbar = !rutasSinNavbar.includes(event.url);
    })
  }
}
