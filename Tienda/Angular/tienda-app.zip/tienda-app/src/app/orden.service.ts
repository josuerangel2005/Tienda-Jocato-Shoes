import { Injectable } from '@angular/core';
import { OrdenRequest } from './OrdenRequest';
import { ProductoCantidad } from './ProductoCantidad';
import { Router } from '@angular/router';
import { ProductoService } from './producto.service';
import { AuthService } from './auth.service';
import { ImagenService } from './imagen.service';
import { CrearCuentaService } from './crear-cuenta.service';
import { EmailService } from './email.service';
import { Usuario } from './Usuario';
import { Orden } from './Orden';
import { EmailRequest } from './EmailRequest';

@Injectable({
  providedIn: 'root',
})
export class OrdenService {
  usuario!: Usuario;

  constructor(
    private router: Router,
    private productoService: ProductoService,
    private authService: AuthService,
    private imagenService: ImagenService,
    private crearCuentaService: CrearCuentaService,
    private emailService: EmailService
  ) {
    this.obtenerUsuario(this.authService.getUserInfo()?.get('username'));
  }

  public obtenerUsuario(username: string) {
    this.crearCuentaService.getUsuarioByUsername(username).subscribe({
      next: (data: Usuario) => {
        this.usuario = data;
      },
    });
  }

  guardarCompra(
    repeticiones: { [nombre: number]: number },
    total: number
  ): void {
    let productosCantidad: ProductoCantidad[] = [];

    for (let clave in repeticiones) {
      productosCantidad.push(
        new ProductoCantidad(Number(clave), repeticiones[clave])
      );
    }

    this.crearCuentaService
      .getUsuarioByUsername(this.authService.getUserInfo()?.get('username'))
      .subscribe({
        next: (data: Usuario) => {
          const user: Usuario = data;

          const orden: OrdenRequest = new OrdenRequest(
            data.username,
            data.direccion,
            data.nombre,
            data.apellido,
            data.documento,
            total,
            productosCantidad
          );

          this.productoService.generarPDFCompra(orden).subscribe({
            next: (data: string): void => {
              const byteCharacters = atob(data);
              const byteNumbers = Array.from(byteCharacters, (char) =>
                char.charCodeAt(0)
              );
              const byteArray = new Uint8Array(byteNumbers);

              const pdfFile = new File([byteArray], 'factura.pdf', {
                type: 'application/pdf',
              });

              const formData: FormData = new FormData();
              formData.append('file', pdfFile);

              this.imagenService.guardarImagen(formData).subscribe({
                next: (data: string) => {
                  const urlPDF = data;
                  const orden: Orden = new Orden(
                    user.username,
                    user.direccion,
                    user.nombre,
                    user.apellido,
                    user.documento,
                    total,
                    data,
                    productosCantidad
                  );
                  this.productoService.guardarOrden(orden).subscribe({
                    next: (data: Orden) => {
                      this.emailService
                        .enviarEmail(
                          new EmailRequest(
                            this.usuario.email,
                            'Gracias por su compra',
                            `<p>Hola ${this.usuario.username}, gracias por su compra. Puede consultar su factura <a href='${urlPDF}'>aquí</a>.</p>`
                          )
                        )
                        .subscribe((data) => {
                          localStorage.removeItem('productos');
                          this.router.navigate(['/productos']);
                        });
                    },
                    error: (err) => console.error(err),
                  });
                },
                error: (err) => console.error(err),
              });
            },
            error: (err) => console.error(err),
          });
        },
        error: (err) => console.error(err),
      });
  }
}
