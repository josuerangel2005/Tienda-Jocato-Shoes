import { Component, OnInit } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { Producto } from '../Producto';
import { ProductoService } from '../producto.service';
import { CommonModule } from '@angular/common';
import { ProductoResponse } from '../ProductoResponse';
import { Route, Router, RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-productos',
  imports: [CommonModule, RouterModule],
  templateUrl: './productos.component.html',
  styleUrl: './productos.component.css',
})
export class ProductosComponent implements OnInit {
  productos: Producto[] = [];
  productosSubscription: Subscription | null = null;
  esAdmin!: boolean;
  productosAgregados: Producto[] = [];
  agregado:boolean = false;
  cantidad:number = 0


  constructor(
    private productoService: ProductoService,
    private authService: AuthService,
  private router:Router) {}

  ngOnInit(): void {
    this.cantidad = JSON.parse(localStorage.getItem('productos') || '[]').length;

    this.cargarProducto();

    //Actualizo los productos
    this.productosSubscription =
      this.productoService.productosActualizados.subscribe(
        (productos: ProductoResponse) => {
          this.productos = productos.productoResponse.productos;
        }
      );

    this.validarAdmin();

  }

  public validarAdmin(): void {
    if (this.authService.getUserInfo()?.get('roles')[0] === 'ROLE_ADMIN')
      this.esAdmin = true;
    else this.esAdmin = false;
  }

  public cargarProducto() {
    this.productoService
      .obtenerProductos()
      .subscribe((data: ProductoResponse) => {
        this.productos = data.productoResponse.productos;
        this.productoService.setProductos(data);
      });
  }

  public eliminarProducto(id: number | undefined) {
    if (id) {
      this.productoService
        .borrarProducto(id)
        .subscribe((data: ProductoResponse) => {
          console.log(data);
          this.cargarProducto();
        });
    }
  }

  agregarProducto(id: number | undefined): void {
    if (id === undefined) return;

    const producto = this.productos.find((x: Producto) => x.productoId === id);
    if (producto){
       this.productosAgregados = JSON.parse(localStorage.getItem('productos') || '[]');
       this.productosAgregados.push(producto);
       this.agregado = true;
       localStorage.setItem('productos',JSON.stringify(this.productosAgregados));
       

       const invalidar = setTimeout(() => {
        this.agregado = false;
       },1000);

    this.cantidad = JSON.parse(localStorage.getItem('productos') || '[]').length;

    }

  }

  redirigir(){
    if(JSON.parse(localStorage.getItem('productos')!).length) this.router.navigate(['/carrito'])
  }

  ngOnDestroy(): void {
    if (this.productosSubscription != null) {
      this.productosSubscription.unsubscribe();
    }
  }


}
