import { Component } from '@angular/core';
import { Producto } from '../Producto';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';


@Component({
  selector: 'app-carrito',
  imports: [CommonModule],
  templateUrl: './carrito.component.html',
  styleUrl: './carrito.component.css',
})
export class CarritoComponent {
  productosAgregados: Producto[] = [];
  repeticiones: { [nombre: number]: number } = {};
  total: number = 0;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.cargarProductos();
    this.calcularTotal();
  }

  public cargarProductos(): void {
    const productos: Producto[] = JSON.parse(
      localStorage.getItem('productos') || '[]'
    );

    console.log(productos);

    this.repeticiones = productos.reduce(
      (acc: { [id: number]: number }, producto) => {
        const id = producto.productoId!;
        acc[id] = (acc[id] || 0) + 1;
        return acc;
      },
      {}
    );

    productos.forEach((x: Producto) => {
      if (!this.productosAgregados.some((p) => p.nombre === x.nombre))
        this.productosAgregados.push(x);
    });
  }

  public eliminarProducto(
    productoId: number,
    idProducto: number | undefined
  ): void {
    if (!idProducto) return;
    this.productosAgregados.splice(productoId, 1);
    localStorage.removeItem('productos');
    localStorage.setItem('productos', JSON.stringify(this.productosAgregados));
    delete this.repeticiones[idProducto];
    this.calcularTotal();
    if (this.productosAgregados.length < 1)
      this.router.navigate(['/productos']);
  }

  modificar(i: number, idProducto: number | undefined, index: number): void {
    if (!idProducto) return;

    if (this.repeticiones[idProducto] === 1 && i === -1) {
      this.eliminarProducto(index, idProducto);
      delete this.repeticiones[idProducto];
      this.calcularTotal();
      return;
    }

    this.repeticiones[idProducto] += i;
    this.calcularTotal();
  }

  calcularTotal(): void {
    this.total = 0;
    for (let producto of this.productosAgregados) {
      this.total += this.repeticiones[producto.productoId!] * producto.precio;
    }
  }
}
