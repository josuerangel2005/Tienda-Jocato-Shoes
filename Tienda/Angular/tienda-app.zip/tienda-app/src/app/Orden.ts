import { ProductoCantidad } from './ProductoCantidad';

export class Orden {
  username: string;
  direccion: string;
  nombre: string;
  apellido: string;
  documento: string;
  total: number;
  urlPDF: string;
  productos: ProductoCantidad[];

  constructor(
    username: string,
    direccion: string,
    nombre: string,
    apellido: string,
    documento: string,
    total: number,
    urlPDF: string,
    productos: ProductoCantidad[]
  ) {
    this.username = username;
    this.direccion = direccion;
    this.nombre = nombre;
    this.apellido = apellido;
    this.documento = documento;
    this.total = total;
    this.urlPDF = urlPDF;
    this.productos = productos;
  }
}
