export class JWT{
    public jwt:string;

    constructor(jwt:string){
        this.jwt = jwt;
    }
}