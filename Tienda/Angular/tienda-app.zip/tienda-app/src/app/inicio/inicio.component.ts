import { Component } from '@angular/core';
import { CarrouselComponent } from './carrousel/carrousel.component';
import { FooterComponent } from "../footer/footer.component";

@Component({
  selector: 'app-inicio',
  imports: [CarrouselComponent, FooterComponent],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css'
})
export class InicioComponent {

}
