import { CommonModule } from '@angular/common';
import { Component, HostListener } from '@angular/core';
import { FormsModule } from '@angular/forms';

interface carouselImages {
  imageSrc: string;
  imageAlt: string;
}

@Component({
  selector: 'app-carrousel',
  imports: [FormsModule, CommonModule],
  templateUrl: './carrousel.component.html',
  styleUrl: './carrousel.component.css',
})
export class CarrouselComponent {
  images: carouselImages[] = [
    {
      imageSrc:
        '/1.png',
      imageAlt: 'Montañas nevadas bajo un cielo azul',
    },
    {
      imageSrc:
        '/2.png',
      imageAlt: 'Atardecer en la playa',
    },
    {
      imageSrc:
        '/3.png',
      imageAlt: 'Bosque de pinos en niebla',
    },
    {
      imageSrc:
        '/4.png',
      imageAlt: 'Reflejo de montañas en un lago',
    },
    {
      imageSrc:
        '/5.png',
      imageAlt: 'Camino entre árboles en otoño',
    },
  ];
  indicators = true;

  isHovering = false;

  interval: any;

  selectedIndex = 0;

  ngOnInit(): void {
    this.interval = setInterval(() =>{
      this.ejecutar(1);
    },7500)
  }

  selectImage(i:number):void{
    this.selectedIndex = i;
    clearInterval(this.interval);
    this.rebobinar()
  }

  ejecutar(i:number):void{
    this.selectedIndex = (this.selectedIndex + this.images.length + i) % this.images.length;
    clearInterval(this.interval);
    this.rebobinar()
  }

  rebobinar():void{
    this.interval = setInterval(() =>{
      this.ejecutar(1);
    },7500)
  }

  onMouseEnter() {
    this.isHovering = true;
  }

  onMouseLeave() {
    this.isHovering = false;
  }

}
