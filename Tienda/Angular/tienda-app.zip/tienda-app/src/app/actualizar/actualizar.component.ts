import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ProductoService } from '../producto.service';
import { NavbarComponent } from '../navbar/navbar.component';
import { CommonModule } from '@angular/common';
import { Producto } from '../Producto';
import { Subscription } from 'rxjs';
import { ProductoResponse } from '../ProductoResponse';
import { ActivatedRoute, Router } from '@angular/router';
import { ImagenService } from '../imagen.service';

@Component({
  selector: 'app-actualizar',
  imports: [FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './actualizar.component.html',
  styleUrl: './actualizar.component.css',
})
export class ActualizarComponent implements OnInit {
  public imagen!: File;
  public carga: boolean = false;
  public id!: number;
  public imguRL: string = '';
  productoForm: FormGroup;
  errorImagen: boolean = false;
  @ViewChild('imageInput') imageInputElement!: ElementRef<HTMLInputElement>;

  productos: Producto[] = [];
  productosSuSubscription: Subscription | null = null;

  constructor(
    private productoService: ProductoService,
    private activeRoute: ActivatedRoute,
    private imagenService: ImagenService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.productoForm = this.formBuilder.group({
      nombre: ['', [Validators.required, Validators.minLength(3)]],
      precio: [null, [Validators.required, Validators.min(0)]],
      marca: ['', [Validators.required, Validators.minLength(3)]],
      descripcion: ['', [Validators.required, Validators.minLength(10)]],
    });
  }

  ngOnInit(): void {
    this.cargarProductos();

    this.productosSuSubscription =
      this.productoService.productosActualizados.subscribe(
        (data: ProductoResponse) => {
          this.productos = data.productoResponse.productos;
        }
      );

    this.id = Number(this.activeRoute.snapshot.paramMap.get('id'));
  }

  public cargarProductos(): void {
    this.productoService
      .obtenerProductos()
      .subscribe((data: ProductoResponse): void => {
        this.productos = data.productoResponse.productos;
        this.productoService.setProductos(data);
        this.cargarDatos();
      });
  }

  public ngOnDestroy(): void {
    if (this.productosSuSubscription != null) {
      this.productosSuSubscription.unsubscribe();
    }
  }

  onFileSelected($event: Event): void {
    const target = $event.target as HTMLInputElement;

    if (target.files && target.files.length > 0) {
      this.imagen = target.files[0];
    }
  }

  public buscarProducto(): Producto | undefined {
    return this.productos.find((x: Producto) => x.productoId === this.id);
  }

  public cargarDatos(): void {
    const producto = this.buscarProducto();
    if (!producto) {
      console.error('Producto no encontrado');
      this.router.navigate(['/productos']);
      return;
    }

    this.productoForm.patchValue({
      nombre: producto.nombre,
      marca: producto.marca,
      precio: producto.precio,
      descripcion: producto.descripcion,
    });
    this.imguRL = producto.urlImage;
  }

  validarProducto(): void {
    if (this.productoForm.invalid) {
      this.productoForm.markAllAsTouched();
      return;
    }
    
    this.actualizarProducto(
      this.productoForm.value.nombre,
      this.productoForm.value.marca,
      this.productoForm.value.precio,
      this.productoForm.value.descripcion,
      this.imagen
    );
  }

  actualizarProducto(
    nombre: string,
    marca: string,
    precio: number,
    descripcion: string,
    imagen: File
  ) {
    this.carga = true;

    // Si el usuario seleccionó una nueva imagen
    if (imagen) {
      this.productoService.borrarFondo(this.imagen).subscribe({
        next: (blob: Blob) => {
          this.imagen = new File([blob], 'imagen_sinFondo.png', {
            type: blob.type,
          });
          const formData: FormData = new FormData();
          formData.append('file', this.imagen);

          this.imagenService.guardarImagen(formData).subscribe({
            next: (url: string) => {
              const producto = new Producto(
                nombre,
                marca,
                precio,
                descripcion,
                url,
                this.id
              );

              this.guardarProductoFinal(producto);
            },
            error: (err) => {
              console.log(`Error al subir la nueva imagen ${err}`);
              this.carga = false;
            },
          });
        },
        error: (err) => console.error(err),
      });
    } else {
      const producto = new Producto(
        nombre,
        marca,
        precio,
        descripcion,
        this.imguRL,
        this.id
      );

      this.guardarProductoFinal(producto);
    }
  }

  private guardarProductoFinal(producto: Producto): void {
    this.productoService.guardarProducto(producto, this.id).subscribe({
      next: (producto: ProductoResponse) => {
 
        this.carga = false;
        this.router.navigate(['/productos']);
      },
      error: (err) => {
        console.log(`Error al actualizar producto: ${err}`);
        this.carga = false;
        this.router.navigate(['/productos']);
      },
    });
  }
}
