import { Routes } from '@angular/router';
import { PrincipalComponent } from './principal/principal.component';
import { ProductosComponent } from './productos/productos.component';
import { ActualizarComponent } from './actualizar/actualizar.component';
import { LoginComponent } from './login/login.component';
import { CrearCuentaComponent } from './crear-cuenta/crear-cuenta.component';
import { AuthGuardService } from './auth-guard.service';
import { FormComponent } from './form/form.component';
import { InicioComponent } from './inicio/inicio.component';
import { CarritoComponent } from './carrito/carrito.component';

export const routes: Routes = [
    {path:'', component:LoginComponent},
    {path:'guardar', component:FormComponent, canActivate: [AuthGuardService]},
    {path:'principal', component:PrincipalComponent, canActivate: [AuthGuardService]},
    {path:'productos', component:ProductosComponent, canActivate: [AuthGuardService]},
    {path:'actualizar/:id', component:ActualizarComponent, canActivate: [AuthGuardService]},
    {path:'crear', component:CrearCuentaComponent},
    {path:'inicio', component:InicioComponent, canActivate: [AuthGuardService]},
    {path:'carrito', component:CarritoComponent}
];
