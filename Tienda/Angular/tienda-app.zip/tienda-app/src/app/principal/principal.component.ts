import { Component } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { FormComponent } from '../form/form.component';

@Component({
  selector: 'app-principal',
  imports: [NavbarComponent, FormComponent],
  templateUrl: './principal.component.html',
  styleUrl: './principal.component.css'
})
export class PrincipalComponent {

}
