import { Component, ElementRef, ViewChild } from '@angular/core';
import { Producto } from '../Producto';
import { ProductoService } from '../producto.service';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ImagenService } from '../imagen.service';
import { ProductoResponse } from '../ProductoResponse';
import { NavbarComponent } from '../navbar/navbar.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-form',
  imports: [FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './form.component.html',
  styleUrl: './form.component.css',
})
export class FormComponent {
  productoForm: FormGroup;
  public imagen!: File;
  public carga: boolean = false;
  errorImagen: boolean = false;
  @ViewChild('imageInput') imageInputElement!: ElementRef<HTMLInputElement>;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private productosService: ProductoService,
    private imagenService: ImagenService
  ) {
    this.productoForm = this.formBuilder.group({
      nombre: ['', [Validators.required, Validators.minLength(3)]],
      precio: [null, [Validators.required, Validators.min(0)]],
      marca: ['', [Validators.required, Validators.minLength(3)]],
      descripcion: ['', [Validators.required, Validators.minLength(10)]],
    });
  }

  onFileSelected($event: Event): void {
    const target = $event.target as HTMLInputElement;

    if (target.files && target.files.length > 0) {
      this.imagen = target.files[0];
    }
  }

  validarProducto(): void {
    if (this.productoForm.invalid) {
      this.productoForm.markAllAsTouched();
      return;
    }
    if (!this.imageInputElement.nativeElement.files?.length) {
      this.errorImagen = true;
      return;
    }else{
      this.errorImagen = false;
    }
    this.guardarProducto(
      this.productoForm.value.nombre,
      this.productoForm.value.marca,
      this.productoForm.value.precio,
      this.productoForm.value.descripcion,
      this.imagen
    );
  }

  guardarProducto(
    nombre: string,
    marca: string,
    precio: number,
    descripcion: string,
    imagen: File
  ) {
    this.productosService.borrarFondo(imagen).subscribe({
      next: (blob: Blob) => {
        this.imagen = new File([blob], 'imagen_sinFondo.png', {
          type: blob.type,
        });
        const formData: FormData = new FormData();
        formData.append('file', this.imagen);

        this.carga = true;

        this.imagenService.guardarImagen(formData).subscribe({
          next: (url: string) => {
            const producto: Producto = new Producto(
              nombre,
              marca,
              precio,
              descripcion,
              url
            );
            this.productosService.guardarProducto(producto).subscribe({
              next: (producto: ProductoResponse) => {
                console.log(producto.productoResponse.productos);
                this.carga = false;
                this.router.navigate(['/productos']);
              },
              error: (err) => {
                console.error(`Error al guardar producto ${err}`);
                this.carga = false;
                this.router.navigate(['/productos']);
              },
            });
          },
          error: (err) => {
            console.log(`Error al subir la imagen ${err}`);
            this.carga = false;
          },
        });
      },
      error: (err) => console.error('Error al borrar el fondo:', err),
    });
  }
}
