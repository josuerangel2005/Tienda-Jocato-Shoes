export class Producto {
  public productoId?: number;
  public nombre: string;
  public marca: string;
  public precio: number;
  public descripcion: string;
  public urlImage: string;

  constructor(
    nombre: string,
    marca: string,
    precio: number,
    descripcion: string,
    urlImage: string,
    productoId?: number
  ) {
    this.productoId = productoId;
    this.nombre = nombre;
    this.marca = marca;
    this.precio = precio;
    this.descripcion = descripcion;
    this.urlImage = urlImage;
  }
}
