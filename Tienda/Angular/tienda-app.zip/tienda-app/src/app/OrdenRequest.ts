import { ProductoCantidad } from "./ProductoCantidad";

export class OrdenRequest{
    username:string;
    direccion:string
    nombre:string;
    apellido:string;
    documento:string
    total:number;
    productos:ProductoCantidad[];

    constructor(username:string,direccion:string, nombre:string, apellido:string, documento:string,total:number, productos:ProductoCantidad[] ){
        this.username = username;
        this.direccion = direccion;
        this.nombre = nombre;
        this.apellido = apellido;
        this.documento = documento;
        this.total = total;
        this.productos = productos;
    }
}