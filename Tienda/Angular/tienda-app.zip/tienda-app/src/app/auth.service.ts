import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';

interface MyJwtPayload {
  sub: string;
  roles: string[];
  exp: number;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private tokenKey: string = 'token';

  constructor() {}

  isLoggedIn(): boolean {
    const token = localStorage.getItem(this.tokenKey);
    return !!token;
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  logout(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem('productos');
    localStorage.clear();
  }

  getUserInfo(): Map<string, any> | null {
    const token = this.getToken();

    if (!token) return null;

    try {
      const payload: MyJwtPayload = jwtDecode(token);
      const info = new Map<string, any>();
      info.set('username', payload.sub);
      info.set('roles', payload.roles);
      return info;
    } catch (e) {
      console.error('Error al decodificar el token: ', e);
      return null;
    }
  }

  isTokenExpired(): boolean {
    const token = this.getToken();
    if (!token) return true;

    try {
      const payload: MyJwtPayload = jwtDecode(token);
      const now = Math.floor(Date.now() / 1000);
      return payload.exp < now;
    } catch {
      return true;
    }
  }
}
