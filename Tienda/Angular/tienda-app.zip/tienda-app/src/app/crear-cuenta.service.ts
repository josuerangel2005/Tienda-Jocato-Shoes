import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Usuario } from './Usuario';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CrearCuentaService {

  url:string = 'http://localhost:8082/api/usuarios'

  constructor(private httpClient:HttpClient) { }

  public getUsuarioByUsername(username:string):Observable<Usuario>{
    return this.httpClient.get<Usuario>(`${this.url}?username=${username}`);
  }

  public guardarUsuario(usuario:Usuario):Observable<Usuario>{
    return this.httpClient.post<Usuario>(this.url, usuario);
  }
}
