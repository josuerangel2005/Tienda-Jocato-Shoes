import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, RouterLink, RouterModule } from '@angular/router';
import { IniciarService } from '../iniciar.service';
import { User } from '../USER';
import { JWT } from '../JWT';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  imports: [RouterLink, FormsModule, ReactiveFormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(
    private iniciar: IniciarService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  validarDatos(): void {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.iniciarSecion(
      this.loginForm.value.username,
      this.loginForm.value.password
    );
  }

  iniciarSecion(username: string, password: string) {
    const user: User = new User(username, password);
    this.iniciar.iniciarSesion(user).subscribe({
      next: (data: JWT) => {
        localStorage.setItem('token', data.jwt);
        this.router.navigate(['/inicio']);
      },
      error: (err) => console.error('Error al iniciar ' + err.error()),
    });
  }
}
